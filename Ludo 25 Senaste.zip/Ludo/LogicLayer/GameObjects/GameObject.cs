﻿namespace Ludo.LogicLayer
{
    public abstract class GameObject
    {
        public GameObject()
        {

        }
    }
}
