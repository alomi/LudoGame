﻿using System.Windows;
using System.Windows.Controls;


namespace Views
{
    /// <summary>
    /// Interaction logic for GamePage.xaml
    /// </summary>
    public partial class GamePage : Page
    {
        public GamePage()
        {
            InitializeComponent();
        }

        private void ButtonClick(object sender, RoutedEventArgs e)
        {

        }

        private void NestClick(object sender, RoutedEventArgs e)
        {

        }

        private void RollDice(object sender, RoutedEventArgs e)
        {

        }

        private void Move(object sender, RoutedEventArgs e)
        {

        }
    }
}
